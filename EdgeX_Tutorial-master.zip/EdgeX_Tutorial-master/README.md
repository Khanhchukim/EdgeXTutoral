# EdgeX_Tutorial
Repository holding files for EdgeX Foundry tutorial located here:
https://jonamiki.com/2020/08/26/edgex-foundry-hands-on-tutorial/
